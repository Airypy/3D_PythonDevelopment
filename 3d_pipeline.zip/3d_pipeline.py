bl_info = {
    "name": "Latest Object",
    "author": "Ashutosh",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > UI > Tool",
    "description": "Exports a Mesh Object in user format",
    "warning": "",
    "doc_url": "",
    "category": "Export Obj",
}

import bpy
from bpy.props import StringProperty, EnumProperty
from bpy_extras.io_utils import ExportHelper

# Define the export operator
class ExportModelOperator(bpy.types.Operator, ExportHelper):
    bl_idname = "export_scene.custom_format"  # Unique identifier for the operator
    bl_label = "Export Model"  # Display name in the interface
    bl_options = {'PRESET'}  # Allow the use of export presets
    filename_ext= ""
    # List of supported export formats
    export_formats = [
        ("OBJ", "Wavefront OBJ", "Export as Wavefront OBJ format"),
        ("FBX", "FBX", "Export as FBX format"),
        # Add more formats here
    ]

    # Properties to store export options
    filepath: StringProperty(subtype="FILE_PATH")  # Filepath to export
    format: EnumProperty(items=export_formats, name="Format")  # Export format

    def execute(self, context):
        if self.format == 'OBJ':
            export_filepath = self.filepath + ".obj"
            bpy.ops.export_scene.obj(filepath=export_filepath, use_selection=True)
            
        elif self.format == 'FBX':
            export_filepath = self.filepath + ".fbx"
            bpy.ops.export_scene.fbx(filepath=export_filepath, use_selection=True)  # Change export settings as needed"
            #Add more format exporters here
        return {'FINISHED'}

    def invoke(self, context, event):
        # Open file dialog
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


# Define the export panel in Blender UI
class ExportModelPanel(bpy.types.Panel):
    bl_label = "Export Model"
    bl_idname = "OBJECT_PT_export_model"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tool'

    def draw(self, context):
        layout = self.layout

        # Add export operator to the panel
        layout.operator("export_scene.custom_format", text="Export Model")

# Register the classes
def register():
    bpy.utils.register_class(ExportModelOperator)
    bpy.utils.register_class(ExportModelPanel)

def unregister():
    bpy.utils.unregister_class(ExportModelOperator)
    bpy.utils.unregister_class(ExportModelPanel)

# Entry point for testing the script
if __name__ == "__main__":
    register()
