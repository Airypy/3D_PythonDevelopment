bl_info = {
    "name": "Json Object",
    "author": "Ashutosh",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > UI > Tool",
    "description": "Exports a JSON",
    "warning": "",
    "doc_url": "",
    "category": "Export JSON Data",
}

import bpy
import json

def get_object_data(obj):
    data = {
        "name": obj.name,
        "location": obj.location[:],
        "rotation": [round(angle * 180 / 3.14159265359, 2) for angle in obj.rotation_euler],
        "scale": obj.scale[:],
        "parent": obj.parent.name if obj.parent else None,
        "children_count": len(obj.children),
    }
    return data

def save_selected_objects_data(filepath):
    selected_objects = bpy.context.selected_objects
    objects_data = [get_object_data(obj) for obj in selected_objects]
    
    with open(filepath, 'w') as json_file:
        json.dump(objects_data, json_file, indent=4)

class SaveObjectDataOperator(bpy.types.Operator):
    bl_idname = "object.save_object_data"
    bl_label = "Save Object Data"
    
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    
    def execute(self, context):
        save_selected_objects_data(self.filepath)
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

def menu_func(self, context):
    self.layout.operator(SaveObjectDataOperator.bl_idname)

def register():
    bpy.utils.register_class(SaveObjectDataOperator)
    bpy.types.VIEW3D_MT_object.append(menu_func)

def unregister():
    bpy.utils.unregister_class(SaveObjectDataOperator)
    bpy.types.VIEW3D_MT_object.remove(menu_func)

if __name__ == "__main__":
    register()
